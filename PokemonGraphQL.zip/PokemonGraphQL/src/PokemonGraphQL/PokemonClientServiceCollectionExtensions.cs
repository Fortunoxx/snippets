namespace Microsoft.Extensions.DependencyInjection
{
    public static partial class PokemonClientServiceCollectionExtensions
    {
    }
}

namespace PokemonGraphQL
{
    public static class Texts
    {
        public static string GetHi => "Hi";
    }
}