﻿// using Microsoft.Extensions.DependencyInjection;

// var serviceCollection = new ServiceCollection();
// serviceCollection
//     .AddPokemonClient()
//     .ConfigureHttpClient(client => client.BaseAddress = new Uri("https://graphqlpokemon.favware.tech/v7"));

// IServiceProvider services = serviceCollection.BuildServiceProvider();

// IPokemonClient client = services.GetRequiredService<IPokemonClient>();

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

var x = Texts.GetHi;