# GraphQL Client
```powershell
dotnet new tool-manifest
dotnet tool install StrawberryShake.Tools --local
dotnet new sln -n PokemonGraphQL
dotnet new classlib --name PokemonGraphQL -o src/PokemonGraphQL
dotnet sln .\PokemonGraphQL.sln add .\src\PokemonGraphQL\
dotnet graphql init https://graphqlpokemon.favware.tech/v7 -n PokemonClient -p .\PokemonGraphQL
```

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>netstandard2.1</TargetFramework>
<!--    <TargetFramework>net7.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable> -->
  </PropertyGroup>
</Project>
```

# create nuget
## add properties to csproj
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>netstandard2.1</TargetFramework>
    <PackageId>PokemonGraphQL</PackageId>
    <Version>1.0.0-alpha</Version>
    <Authors>Rob Gates</Authors>
    <Company>private_company</Company>
  </PropertyGroup>
</Project>
```
## pack
`dotnet pack`

## add to local nuget
`nuget add .\src\PokemonGraphQL\bin\Debug\PokemonGraphQL.1.0.0.nupkg -source R:\nuget_packages`

# create client application
## 
`dotnet new console -n PokemonClient -o src\PokemonClient`

## add nuget source to nuget.config
create local nuget.config
```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <add key="nuget.org" value="https://api.nuget.org/v3/index.json" />
    <add key="nuget_local" value="R:\nuget_packages" />
  </packageSources>
</configuration>
```

## test
`nuget list -source nuget_local -PreReleas`